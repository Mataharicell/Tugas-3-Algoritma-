/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;
import java.util.Scanner;

/**
 *
 * @author NURDIN
 */
public class Menghitungvolumebalok {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        int volume, panjang, lebar, tinggi;
        
        System.out.print("Masukan nilai panjang =");
        panjang = Integer.parseInt(scan.nextLine());
        
        System.out.print("Masukan nilai lebar ="); 
        lebar = Integer.parseInt(scan.nextLine());
        
        System.out.print("Masukan nilai tinggi ="); 
        tinggi = Integer.parseInt(scan.nextLine());
        
        volume = panjang*lebar*tinggi;
        System.out.println("Hasil volume balok ="+volume);
                
        
        
    }
    
}
