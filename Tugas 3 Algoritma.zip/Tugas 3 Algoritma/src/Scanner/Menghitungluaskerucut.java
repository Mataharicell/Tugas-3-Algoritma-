/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Scanner;

import java.util.Scanner;

/**
 *
 * @author NURDIN
 */
public class Menghitungluaskerucut {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        double luas, s, r;
        
        System.out.println("Masukan nilai s =");
        s = Double.valueOf(scan.nextLine());
        
        System.out.println("Masukan nilai r =");
        r = Double.valueOf(scan.nextLine());
        
        luas = 3.14*r*s+3.14*r;
        System.out.println("Hasil luas kerucut ="+luas);
        
    }
    
}
